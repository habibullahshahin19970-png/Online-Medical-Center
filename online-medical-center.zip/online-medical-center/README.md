# Online Medical Center
Upload logo to images/logo.png